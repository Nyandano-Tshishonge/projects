import java.util.Scanner;

public class BattleShips {

    private char[][] grid = new char [10][10];
    //TODO: Add your code here
}
