import java.util.Scanner;

public class BattleShipsApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// TODO: Add your code here
	}
}
