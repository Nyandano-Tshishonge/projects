package checkers;

import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class Piece {
    public static final int BLACK = 0;
    public static final int RED = 1;

    private int color;
    private Image image = null;
    private boolean isCrown = false;

    public Piece(int color) {
        this.color = color;
        try {
            String imagePath = (color == BLACK) ? "/Images/black.gif" : "/Images/red.gif";
            image = ImageIO.read(getClass().getResource(imagePath));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error loading image: " + ex.getMessage(), "Image Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public int getColor() { return color; }
    public boolean isCrown() { return isCrown; }

    public void draw(Graphics g, int x, int y, int height, int width) {
        if (image != null) {
            g.drawImage(image, x, y, height, width, null);
        }
    }

    public void makeCrown() {
        isCrown = true;
        try {
            String crownImagePath = (color == BLACK) ? "/Images/blackcrown.gif" : "/Images/redcrown.png";
            image = ImageIO.read(getClass().getResource(crownImagePath));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading crown image: " + e.getMessage(), "Image Load Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
