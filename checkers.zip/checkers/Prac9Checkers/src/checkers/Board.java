package checkers;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Board extends JPanel implements MouseListener {
    private static final int numRowCol = 8;
    private Square[][] squares = new Square[numRowCol][numRowCol];
    private Square firstSelected = null;
    private Square secondSelected = null;
    private boolean isBlackTurn = true;
    private int numBlack = 12;
    private int numRed = 12;
    private int direction = -1;

    public Board() {
        for (int i = 0; i < numRowCol; i++) {
            for (int j = 0; j < numRowCol; j++) {
                boolean isDark = (i + j) % 2 == 0;
                squares[i][j] = new Square(i, j, isDark);
                if (isDark) {
                    if (i < 3) {
                        squares[i][j].addPiece(new Piece(Piece.BLACK));
                    } else if (i > 4) {
                        squares[i][j].addPiece(new Piece(Piece.RED));
                    }
                }
            }
        }
        this.addMouseListener(this);
        setPreferredSize(new Dimension(Square.SIZE * numRowCol, Square.SIZE * numRowCol));
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        for (Square[] row : squares) {
            for (Square square : row) {
                square.draw(g);
            }
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        Square s = squares[e.getY() / Square.SIZE][e.getX() / Square.SIZE];
        if (isBlackTurn) direction = 1;
        else direction = -1;

        if (this.firstSelected == null) {
            if (s.getPiece() != null) {
                if ((s.getPiece().getColor() == Piece.BLACK && isBlackTurn) ||
                    (s.getPiece().getColor() == Piece.RED && !isBlackTurn)) {
                    firstSelected = s;
                    System.out.println("FIRST SELECTED");
                } else {
                    System.out.println("Not your turn");
                }
            } else {
                System.out.println("Pick another piece");
            }
        } else {
            if (s.getPiece() == null && s != firstSelected) {
                if (Math.abs(firstSelected.getXIndex() - s.getXIndex()) == 1 &&
                    firstSelected.getYIndex() - s.getYIndex() == direction * -1) {
                    secondSelected = s;
                    System.out.println("SECOND SELECTED");
                    move();
                } else if (Math.abs(firstSelected.getXIndex() - s.getXIndex()) == 2 &&
                           firstSelected.getYIndex() - s.getYIndex() == direction * -2) {
                    secondSelected = s;
                    System.out.println("SECOND SELECTED");
                    capture();
                }
            }
        }
    }

    public void capture() {
        int midX = (firstSelected.getXIndex() + secondSelected.getXIndex()) / 2;
        int midY = (firstSelected.getYIndex() + secondSelected.getYIndex()) / 2;
        Square capturedSquare = squares[midY][midX];

        if (capturedSquare.getPiece() != null) {
            if (capturedSquare.getPiece().getColor() != firstSelected.getPiece().getColor()) {
                if (capturedSquare.getPiece().getColor() == Piece.BLACK) numBlack--;
                else numRed--;
                capturedSquare.removePiece();
                move();
            }
        }
    }

    public void move() {
        Piece p = firstSelected.getPiece();
        firstSelected.removePiece();
        secondSelected.addPiece(p);

        if ((isBlackTurn && secondSelected.getYIndex() == 7) ||
            (!isBlackTurn && secondSelected.getYIndex() == 0)) {
            secondSelected.getPiece().makeCrown();
        }

        firstSelected = null;
        secondSelected = null;
        isBlackTurn = !isBlackTurn;
        checkWin();
        repaint();
    }

    public void checkWin() {
        if (numBlack == 0) {
            JOptionPane.showMessageDialog(this, "Red wins");
            System.exit(0);
        }
        if (numRed == 0) {
            JOptionPane.showMessageDialog(this, "Black wins");
            System.exit(0);
        }
    }

    @Override public void mousePressed(MouseEvent e) {}
    @Override public void mouseReleased(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
}
